/*Tasfia Afrida
MRS.Strelkovka
ICS4U
Date: JUNE 22 2021
FINAL PROJECT
Program description: Space shooter game
//Menu panel //
*/
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class MyMenuPanel  extends JPanel implements ActionListener {

    /*Variables*/
    ImageIcon bg = new ImageIcon("Main_space.png"); // background image for this panel
    private JButton  goGame,buttonExit,instructions;

    /*Constructor*/
    public MyMenuPanel(){

        /* create and add action listeners to buttons*/
        goGame=new JButton("Start Game");
        buttonExit = new JButton("Leave Game");
        instructions = new JButton("Instructions");
        goGame.addActionListener(this);
        buttonExit.addActionListener(this);
        instructions.addActionListener(this);

        /* Formatting display of buttons*/
        this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        this.add(Box.createRigidArea(new Dimension(10,250))); // creates space at the top

        goGame.setAlignmentX(Component.CENTER_ALIGNMENT); // horizontal alignment to the center of the frame
        this.add(goGame);
        this.add(Box.createRigidArea(new Dimension(40,45))); // space between the buttons

        instructions.setAlignmentX(Component.CENTER_ALIGNMENT); // horizontal alignment to the center of the frame
        this.add(instructions);
        this.add(Box.createRigidArea(new Dimension(40,45))); // space between the buttons

        buttonExit.setAlignmentX(Component.CENTER_ALIGNMENT); // horizontal alignment to the center of the frame
        this.add(buttonExit);
        this.add(Box.createRigidArea(new Dimension(40,45))); // space between the buttons


    }
    public void actionPerformed(ActionEvent e) {    // Button Actions

        if(e.getSource()==goGame) {
            JOptionPane.showMessageDialog(null, "START GAME?", "S P A C E   S H O O T E R ", JOptionPane.INFORMATION_MESSAGE);

            MyGamePanel gameP = new MyGamePanel();
            MyMenuPanel  menuP = new MyMenuPanel();
            /*Resets the Game panel and starts again if Player wants to play again */
            Main.c.removeAll();
            Main.c.add("MenuNickName", menuP);
            Main.c.add("GameNickName", gameP);
            Main.cardsL.next(Main.c);
        }

        if(e.getSource()==buttonExit) { // exits game
            System.exit(0); // Stops the program
        }

        if(e.getSource()==instructions) { // displays instructions
            JOptionPane.showMessageDialog(null, "Use arrow keys to move and press W to shoot.\nAvoid collisions with asteroids\nStay within the frame or else you will lose hp ", "I N S T R U C T I O N S ", JOptionPane.INFORMATION_MESSAGE);
        }

    } // end of action performed

    public void paintComponent(Graphics g){     // Paint component for main menu
        super.paintComponent(g);
        g.drawImage(bg.getImage(),0,0,562,787,null);
        g.setColor(Color.white);
        g.setFont(new Font("Monospaced", Font.BOLD+Font.ITALIC, 24));  // set font

    }//end of paint

}// end of MyMenuPanel class
