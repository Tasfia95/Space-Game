/*Tasfia Afrida
MRS.Strelkovka
ICS4U
Date: JUNE 22 2021
FINAL PROJECT
Program description: Space shooter game
//Player Class//
*/
import java.awt.*;
import java.awt.image.*;


class Player {

    /* Variables */
    private int x_s,y_s,size,hp,max_hp,minus;
    private int vel;
    private BufferedImage playerImg=null;
    private  boolean visable = true;
    private double minus2;


    /*  Player Constructor */
    public Player(int x,int y){

        this.x_s=x;
        this.y_s=y;

        vel=10;  // velocity
        size=10; // size

        max_hp=hp=135; // max hp is 100
        minus=5; // used when player touches border of the frame
        minus2=0.000000000001; // used when player collides with asteroid
    }

    /*Player move methods*/
    public void move_right(){
        x_s+=vel; // velocity on the x-coordinate
        vel*=-1;
        if(x_s>335)
        {
            hp-=minus; // loses hp if player hits the borders
        }
    }
    public void move_left()
    {
        x_s-=vel;
        vel*=-1;
        if(x_s<=-110)
        {
            hp-=minus;
        }
    }
    public void move_up()
    {
        y_s-=vel;
        vel*=-1;

        if(y_s<=-100)
        {
            hp-=minus;
        }
    }
    public void move_down ()
    {
        y_s+=vel;
        vel*=-1;

        if(y_s>=555 )
        {
            hp-=minus;
        }
    }

    /*Getter and Setter methods*/
    public int getX_s()
    {
    return x_s;
    }
    public int getY_s ()
    {
    return y_s;
    }

    public int getHp()
    {
    return  hp;
    }
    public void setSpeed ()
    {
        vel=10;
    }
    public void see_player()
    {
        hp-=minus2; // minus one if gets shot by a bullet
        if(hp<=0)
        {
            visable=false;
        }
    }
    public void see_player2()
    {
        visable=false;
    }

    /*Draws player and health bar*/
    public void myDraw(Graphics g){ // drawing player component

        if(visable) {
            playerImg = SpaceShip_Image.getShipImg();
            g.setColor(Color.red);
            g.fillRect(390, 10, max_hp, 10);//hp bar
            g.setColor(Color.green);
            g.fillRect(390, 10, hp, 10); //hp bar
            g.setColor(Color.white);
            g.setFont(new Font(" Helvetica", Font.BOLD + Font.ITALIC, 15));  // set font
            g.drawString("Health:", 330, 20);   // display the string starting at the coordinate (165, 150)
            g.drawImage(playerImg, x_s, y_s, null); // player draw
        }
    }

}//end of player class