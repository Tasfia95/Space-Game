/*Tasfia Afrida
MRS.Strelkovka
ICS4U
Date: JUNE 22 2021
FINAL PROJECT
Program description: Space shooter game
//Game Panel//
*/
/// Game Menu Panel ///
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class MyGamePanel extends JPanel implements ActionListener, KeyListener,MouseListener {

    /*Variables*/
    ImageIcon b2 = new ImageIcon("black_space2.jpg");
    private JButton  goMenu;
    private Player player;
    private int asteroid_counter=0;
    private int point;
    private boolean show_explosion,lost=false;
    private boolean shoot=true;

    /*Array lists*/
    ArrayList<Asteroid>allAsteroids=new ArrayList<Asteroid>(); //Asteroids array list
    ArrayList<Bullets>bullet=new ArrayList<Bullets>();        //Bullets array list

    Timer mytimer = new Timer (15, this); // timer


    /*Constructor*/
    public MyGamePanel(){

        player = new Player(140,500);// creates the spaceship at x,y coordinates

        /*Create Asteroid objects at set X,Y coordinates*/
        Asteroid asteroid1 = new Asteroid(230,100);
        asteroid1.setMovement((int) (Math.random()*2)); // Generates a random number to set the movement to

        Asteroid asteroid2 = new Asteroid(300,96);
        asteroid2.setMovement((int) (Math.random()*2));

        Asteroid asteroid3 = new Asteroid(127,300);
        asteroid3.setMovement((int) (Math.random()*2));

        Asteroid asteroid4 = new Asteroid(102,403);
        asteroid4.setMovement((int) (Math.random()*2));

       /*Adds the asteroids to the array list*/
       allAsteroids.add(asteroid1);
       allAsteroids.add(asteroid2);
       allAsteroids.add(asteroid3);
       allAsteroids.add(asteroid4);

       /*Adding buttons and layouts*/
        goMenu=new JButton("Back to Main Menu");
        goMenu.addActionListener(this);
        this.setLayout(new BoxLayout(this,BoxLayout.PAGE_AXIS));// set button to right of panel
        this.add(goMenu);

        /*Loading images*/
        SpaceShip_Image.loadImages();
        Asteroid_Image.loadImages2();

        /*Adding all listeners to the panels*/
        this.addKeyListener(this);
        this.addMouseListener(this);
        this.setFocusable(true); // sets focus on game panel and makes key press detectable
        this.requestFocusInWindow(); // sets focus on game panel and makes key press detectable

    }

    @Override /*Moving Player when key is pressed*/
    public void keyPressed(KeyEvent e) {
        int key =  e.getKeyCode(); // getting keycode

        if (key==39) // right arrow key
        {
            player.setSpeed();
            player.move_right();
            repaint();
        }
        if (key==37) // left arrow key
        {
            player.setSpeed();
            player.move_left();
            repaint();
        }
        if (key==38) // up arrow key
        {
            player.setSpeed();
            player.move_up();
            repaint();
        }
        if (key==40) // down arrow key
        {
            player.setSpeed();
            player.move_down();
            repaint();
        }
        if (key==87) // press W to shoot
        {
            if(shoot) { // checking if the player is still able to shoot
                System.out.println("Bullets being shot");
                bullet.add(new Bullets(player.getX_s() + 150, player.getY_s() + 100)); // adds bullets at X,Y coordinates
            }
        }
    }// End of key pressed

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == goMenu) {     // switches back to main menu and resets the score
            Main.cardsL.next(Main.c);
            if (point > 0) {
                point = 0;
            }
        } else {
            if(player.getHp()<=0) // if player loses the game, prints that they have lost and removes bullets and player
            {
                lost=true;
                shoot=false;
                player.see_player2();
            }

            for (int i = 0; i < bullet.size(); i++) {    // move all the bullets
                bullet.get(i).myMove();
            }
            /*Going through asteroid list and assigning asteroids move methods*/
            for(int j =0; j<allAsteroids.size();j++) {
                Asteroid asteroid= allAsteroids.get(j);
                if (asteroid.getMovement() == 0) {
                    asteroid.moveDown();
                } else if (asteroid.getMovement() == 1) {
                    asteroid.moveLeft();
                } else if (asteroid.getMovement() == 2) {
                    asteroid.moveRight();
                }

                /*Specific X & Y points of asteroid to detect proper collision with bullets*/
                int a_x1 = asteroid.getX() + 180;
                int a_x2 = asteroid.getX() + 60;

                int a_y1 = asteroid.getY();
                int a_y2 = asteroid.getY() + 140;

                if((player.getX_s()+200<= a_x1)&&(player.getX_s()+200>= a_x2)) {    // detecting asteroid collision with player
                    if(player.getY_s()+80>= a_y1 && (player.getY_s()+80<= a_y2)) {
                       player.see_player(); // if collision detected, call the method that subtracts player hp
                    }
                }

                /*Checking for Bullet Collision with Asteroids*/
                for (int i = 0; i < bullet.size(); i++)
                {
                    Bullets unit = bullet.get(i);
					if ((unit.getY() <=80 )) // removes bullets at the top of the frame
                    { bullet.remove(i);
                    }
                    if ((unit.getX() <= a_x1) && (unit.getX() >= a_x2)) { //checking X collision
                        if ((unit.getY() >= a_y1) && (unit.getY() <= a_y2)) { // checking Y collision
                            System.out.println("collision");
                            asteroid.see_asteroid(); //calls method that removes asteroids hp
                            bullet.remove(i); // removes bullets if they collide with asteroids
                            if(asteroid.getHp() <= 0) {
                                allAsteroids.remove(j); // removes asteroids if their hp<=0
                                asteroid_counter++;     // adds to the counter of how many asteroids the player shot
                                point+=100;             // adds points
                                if(asteroid_counter>=4) // checks if player cleared all the asteroids
                                {
                                    show_explosion=true;  // allows explosion recuring drawing to be drawn
                                    player.see_player2();  // removes player
                                    shoot=false;           // stops shooting

                                }
                            }
                        }
                    }
                }
            }

        }
            repaint();
    } // end of action performed

    /*Paint component for Game panel*/
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(b2.getImage(),0,0,562,850,null);// background image for game panel
        mytimer.start();

        /*Score displaying*/
        g.setColor(Color.white);
        g.setFont(new Font("Monospaced", Font.BOLD+Font.ITALIC, 20));
        g.drawString("Score:" +point,430,38);

        player.myDraw(g); // drawing player

        for(Asteroid asteroid : allAsteroids) // drawing all asteroids
        {
            asteroid.myDrawAsteroid(g);
        }

        for (int i =0; i<bullet.size();i++)   // drawing bullets
        {
            bullet.get(i).myDraw(g);
        }

        if(show_explosion) { // checking if the game ended
            drawCircle(g, 208, 296, 150); // draws explosion
            endgame(g);// displays the player has won
        }
        if(lost) // checks if the player lost game
        {
            showlost(g); // displays the player has lost
        }
    }//end of paint component

    /*Recursion explosion*/
    public void drawCircle(Graphics g , int x,int y, int size) // Recursion Graphics
    {
        if (size<5)
            return;
            Graphics2D g2d = (Graphics2D)g;
            g.setColor(Color.yellow);
            g.fillOval(x,y,size,size);
            g2d.setPaint(new Color(255, 10,5 ));
            g.drawOval(x,y,size,size);
            drawCircle(g,x-size/4,y-size/4,size/2);
            drawCircle(g,x+size-size/4,y-size/4,size/2); // right side explosion
            drawCircle(g,x+size-size/4,y+size-size/4,size/2); // right bottom
            drawCircle(g,x-size/4,y+size-size/4,size/2); // left bottom
        repaint();
    }

    public void endgame(Graphics g) // displays if player wins
    {
        g.setColor(Color.white);
        g.setFont(new Font("Monospaced", Font.BOLD+Font.ITALIC, 30));  // set font
        g.drawString("WINNNN!!!",215,200);
    }

    public void showlost(Graphics g) // displays if player lost
    {
        g.setColor(Color.white);
        g.setFont(new Font("Monospaced", Font.BOLD+Font.ITALIC, 30));  // set font
        g.drawString("LOST, restart the game",95,200);
    }

    /*Unused*/
    public void keyTyped(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
}// end of MyGamePanel class
