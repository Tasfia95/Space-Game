/*Tasfia Afrida
MRS.Strelkovka
ICS4U
Date: JUNE 22 2021
FINAL PROJECT
Program description: Space shooter game
//Asteroids Class//
*/
import java.awt.*;
import java.awt.image.BufferedImage;

public class Asteroid {

    /* Variables */
    private int x;
    private int y;
    private int hp;
    private int max_hp;
    private int minus;
    private int vel;
    private boolean visable=true;
    private BufferedImage asteroidImg=null;
    private int cnt=1;
    private int movement = 0;


    /*  Player Constructor */
    public Asteroid(int x,int y){

        this.x=x;
        this.y=y;

        vel=1;  // velocity
        max_hp=hp=90; // health of asteroid
        minus=(hp/10*2); // - 20% of original hp
    }
    public void moveRight ()
    {
        x+=vel; // velocity on the x-coordinate

        if (x>=350) // checks if hit the right side
        {
            if(vel>0){

                vel*=-1;
            }
        } else if (x<=0)
        {
            if(vel<0){

                vel*=-1;
            }
        }
    }
    public void moveDown ()
    {
        y+=vel;

        if (y>=500) // if hit near bottom of screen
        {
            if(vel>0){

                vel*=-1;
            }

        } else if (y<=5)
        {
            if(vel<0){

                vel*=-1;
            }
        }
    }
    public void moveLeft ()
        {
        x+=vel;
        if (x<=0) // if hit the left side
        {
            if(vel<0){

                vel*=-1;
            }   // moves to the opposite direction
        } else if (x>=350 )
        {
            if(vel>0){

                vel*=-1;
            }
        }
    }
/*Getter and Setter methods*/
    public int getX ()
    {
        return x;
    }

    public int getY ()
    {
        return y;
    }

    public int getHp() {
        return hp;
    }

    public int getMovement() {
        return movement;
    }

    public void setMovement(int movement) {
        this.movement = movement;
    }

    public void see_asteroid()
    {
        hp-=minus; // minus one if gets shot by a bullet
        if(hp<=0)
        {
            visable=false;
        }
    }

    /*Drawing asteroids and their health bars*/
    public void myDrawAsteroid(Graphics g){ // drawing player component

        if(visable) {
            asteroidImg = Asteroid_Image.getAsteroidImg(cnt); // // gets the asteroids image
            g.setColor(Color.red);
            g.fillRect(x + 75, y + 70, max_hp, 5);//hp bar
            g.setColor(Color.green);
            g.fillRect(x + 75, y + 70, hp, 5); //hp bar
            g.drawImage(asteroidImg, x, y, null); // draws the asteroids
        }
    }

}
