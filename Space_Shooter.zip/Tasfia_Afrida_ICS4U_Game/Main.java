/*Tasfia Afrida
MRS.Strelkovka
ICS4U
Date: JUNE 22 2021
FINAL PROJECT
Program description: Space shooter game
//Main Class//
*/
import javax.swing.*;
import java.awt.*;

public class Main extends JFrame{

    static CardLayout cardsL;
    static Container c;

    MyMenuPanel  menuP;  //  menu panel
    MyGamePanel gameP;  //  game panel

    public Main(){

        // Setting Up and adding New Game/Menu Panel//

        c= getContentPane();
        cardsL = new CardLayout();
        c.setLayout(cardsL);

        gameP = new MyGamePanel();
        menuP = new MyMenuPanel();;

        c.add("MenuNickName", menuP);
        c.add("GameNickName", gameP);

    }
    public static void main(String[] args) {

        Main a = new Main(); // main object

        a.gameP.repaint(); // repaints game panel
        a.setSize(562,787);
        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // make frame closed when x button is pressed

    }
}
