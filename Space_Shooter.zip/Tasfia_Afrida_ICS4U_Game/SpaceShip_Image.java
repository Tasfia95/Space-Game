/*Tasfia Afrida
MRS.Strelkovka
ICS4U
Date: JUNE 22 2021
FINAL PROJECT
Program description: Space shooter game
//SpaceShip Image Class//
*/
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public class SpaceShip_Image {
    private static BufferedImage spriteImg,shipImg;

    public static void loadImages(){
        try{
            spriteImg = ImageIO.read(new File("space_ship2-2-1.png"));
        }catch(Exception e){
            System.out.print("Error" + e);
        }

        shipImg = spriteImg.getSubimage(525,442,250,200); // ship image and subimage points

    }

public static BufferedImage getShipImg ()
{
    return shipImg;
}


}//end of Image class
