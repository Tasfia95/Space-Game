/*Tasfia Afrida
MRS.Strelkovka
ICS4U
Date: JUNE 22 2021
FINAL PROJECT
Program description: Space shooter game
//Asteroid Image class//
*/
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public class Asteroid_Image {
    private static BufferedImage spriteImg;
    private static BufferedImage asteroidImg[] ;


    public static void loadImages2(){
        try{
            spriteImg = ImageIO.read(new File("asteroid.png"));
        }catch(Exception e){
            System.out.print("Error" + e);
        }

        /*Array of 4 images*/
        asteroidImg = new BufferedImage[4];
        asteroidImg[0]=spriteImg.getSubimage(525,342,250,200); // subimage points for asteroids
        asteroidImg[1]=spriteImg.getSubimage(525,342,250,200);
        asteroidImg[2]=spriteImg.getSubimage(525,342,250,200);
        asteroidImg[3]=spriteImg.getSubimage(525,342,250,200);

    }

    public static BufferedImage getAsteroidImg (int cnt)
    {
         cnt+=1;
        return asteroidImg[cnt];
    }

}
