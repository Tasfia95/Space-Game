/*Tasfia Afrida
MRS.Strelkovka
ICS4U
Date: JUNE 22 2021
FINAL PROJECT
Program description: Space shooter game
//Bullets Class//
*/
import java.awt.*;
public class Bullets{
    /*Variables*/
    int x, y, width, dx, dy;

    /*Constructor*/
    public Bullets(int x, int y) {
        this.x=x;
        this.y=y;
        width=8;
        dx=0;
        dy=-5;
    }

    public void myMove() { // move method for bullets
        x+=dx;
        y+=dy;
    }
    public void myDraw(Graphics g) { // drawing bullets
        Graphics2D g2d = (Graphics2D) g;
        g2d.setPaint(new Color(37, 232,219 )); // set new color
        g.fillOval(x, y, width,width);
    }

    /*Getter methods*/
    public int getX ()
    {
        return x;
    }
    public int getY ()

    {
    return y;
    }

}